Perubahan yang dilakukan
- Menambah berita pertama dari berita1.txt ke basis_data.sql
- Menambah table komentar pada basis_data.sql
- Menambahkan fitur kolom komentar di baca_berita.php
- Menampilkan daftar komentar yang ada
- Penambahan Styling pada gaya.css